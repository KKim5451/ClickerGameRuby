module ClickerHelper
end
