Given("I am on the game screen") do
  visit "https://software-engineering-class-tanishere.c9users.io/clicker"
end

When("I click on the {string} link") do |string|
  page.find_by_id(string).tag_name
end

Then("The {string} should text should be there which holds the number of clicks") do |string|
  expect(page).to have_content(string)
end

When("I click on the {string} items") do |string|
  expect(page).to have_content(string)
end

Then("The {string} is visable") do |string|
   expect(page).to have_content(string)
end

When("I gain acheivments") do
  #This should always pass the test
end

Then("I should see them in the {string} view") do |string|
  expect(page).to have_content(string)
end
